// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'custom_dio.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $CustomDio = BindInject(
  (i) => CustomDio(i<BaseOptions>()),
  singleton: true,
  lazy: true,
);
