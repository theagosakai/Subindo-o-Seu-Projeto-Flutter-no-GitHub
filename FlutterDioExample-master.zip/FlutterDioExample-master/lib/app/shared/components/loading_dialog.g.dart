// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'loading_dialog.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $LoadingDialog = BindInject(
  (i) => LoadingDialog(),
  singleton: false,
  lazy: true,
);
