// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_repository.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $UserRepository = BindInject(
  (i) => UserRepository(i<DioForNative>()),
  singleton: true,
  lazy: true,
);
