// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_service.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $UserService = BindInject(
  (i) => UserService(i<IUserRepository>()),
  singleton: true,
  lazy: true,
);
