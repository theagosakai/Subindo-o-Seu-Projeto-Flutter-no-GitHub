// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_repository.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $ProductRepository = BindInject(
  (i) => ProductRepository(i<DioForNative>()),
  singleton: true,
  lazy: true,
);
