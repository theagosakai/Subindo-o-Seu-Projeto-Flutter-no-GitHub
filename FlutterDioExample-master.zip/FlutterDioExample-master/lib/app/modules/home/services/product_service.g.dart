// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_service.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $ProductService = BindInject(
  (i) => ProductService(i<IProductRepository>()),
  singleton: true,
  lazy: true,
);
